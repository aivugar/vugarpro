<?php //phpcs:ignoreFile
/**
 * Empty file.
 */

// Silence is golden.
