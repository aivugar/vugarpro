<?php
namespace Automattic\Jetpack_Boost\Contracts;

interface Has_Slug {
	public static function get_slug();
}
