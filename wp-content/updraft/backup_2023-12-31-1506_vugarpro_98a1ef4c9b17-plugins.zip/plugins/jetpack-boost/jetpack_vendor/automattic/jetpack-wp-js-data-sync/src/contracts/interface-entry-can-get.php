<?php

namespace Automattic\Jetpack\WP_JS_Data_Sync\Contracts;

interface Entry_Can_Get {

	public function get();
}
